/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      backgroundImage: () =>({
        'SignInImg' : "url('/src/Assets/Images/SignIn.jpg')",
        'ForgotPassImg' : "url('/src/Assets/Images/ForgotPass.jpg')",
        'ChatBG' : "url('/src/Assets/Images/chatBG.jpg')"
      })
    },
  },
  plugins: [
    require('@tailwindcss/forms')
  ],
}