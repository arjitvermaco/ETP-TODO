import ContactsComponent from "../Components/ContactsComponent"
import MessageComponent from "../Components/MessageComponent"

export default function Chat()
{
  return(
      <div className='flex relative'>
          <ContactsComponent/>
          <MessageComponent/>
      </div>
  );
}