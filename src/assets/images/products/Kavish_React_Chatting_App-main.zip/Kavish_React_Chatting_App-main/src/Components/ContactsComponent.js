import {collection, getDocs} from "firebase/firestore";
import {db} from "../Firebase";
import {useContext, useEffect, useState} from "react";
import UsersComponent from "./UsersComponent";
import MobileFriendlyNavBar from "./MobileFriendlyNavBar";
import authContext from "../Context/Authentication/AuthContext";


export default function ContactsComponent()
{
    const [users,setUsers] = useState([]);
    const auth = useContext(authContext)

    useEffect(()=>{
        getAllUsers().then()
    },[])

    async function getAllUsers()
    {
        const usersSnapshot = await getDocs(collection(db,"Users"));
        const usersList = usersSnapshot.docs.map((doc)=>{
            return {...doc.data() , ...{uid : doc.id}};
        })
        setUsers(usersList)
    }

  return(

      <div className={"xl:w-[25%]"}>

          <MobileFriendlyNavBar users={users}/>

          <div className="hidden lg:block bg-gray-300 overflow-auto h-screen border-2 border-gray-400">

              <div className={"py-5 border-2 border-t-0 border-l-0 border-r-0 border-b-gray-400 sticky top-0 bg-gray-300"}>

                  <p className={"text-center text-xl font-semibold" }>\/ People on this group \/</p>

              </div>


              <div className="divide-y divide-gray-500">
                  {users.map((user) => {
                      if(auth.userInfo.userName!==user.name)
                      {
                          if (user.uid===auth.chattingUser)
                          {
                              return <UsersComponent key={user.uid} user={user} selectedUser={"bg-blue-300"} />
                          }
                          return <UsersComponent key={user.uid} user={user} />
                      }
                      return null
                  })}

              </div>


          </div>

      </div>

  );
}