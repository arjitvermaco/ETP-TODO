export default function SingleMessageComponent({msg , dynamicBodyCss , dynamicHeadingCss , alignMsg , messagesEndRef })
{
  return(
      <div className={"flex flex-col "+alignMsg} ref={messagesEndRef} >
          <div className={"rounded-lg w-fit pb-1 max-w-[45%] md:max-w-lg  mx-3 mt-4 mb-9 "+dynamicBodyCss}>

              <div className={"rounded-t-lg font-bold text-white px-3 py-1 "+dynamicHeadingCss}>
                  <p>{msg.name}</p>
              </div>

              <div className={"mx-3 my-2 break-words"}>
                  <p> {msg.messageBody} </p>
              </div>

              <div className={"text-end font-semibold text-sm italic mx-3"}>
                  <p> { msg.createdAt } </p>
              </div>

          </div>
      </div>
  );
}