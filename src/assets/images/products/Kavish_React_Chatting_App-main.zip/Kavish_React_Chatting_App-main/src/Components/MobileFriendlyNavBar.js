import {useContext} from "react";
import authContext from "../Context/Authentication/AuthContext";
import UsersComponent from "./UsersComponent";
import {Link} from "react-router-dom";

export default function MobileFriendlyNavBar({users})
{
    const auth = useContext(authContext)
  return(

      <div className={`lg:hidden max-h-screen min-h-screen z-40 absolute transition-all duration-200 ease-in ${auth.navbarOpen? "w-72" : "w-0"} bg-gray-300 border-2 border-gray-400`}>

          <div className={"absolute -right-16 top-5 text-blue-600 bg-white pl-2 pr-3 rounded-r-full"} onClick={()=>{auth.setNavbarOpen(!(auth.navbarOpen))}} >
              <svg xmlns="http://www.w3.org/2000/svg" className={`h-10 w-10 transition-all duration-500 ease-in ${auth.navbarOpen? "rotate-180" : "rotate-0"}`} fill="none" viewBox="0 0 24 24"
                   stroke="currentColor" strokeWidth="2">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13 5l7 7-7 7M5 5l7 7-7 7"/>
              </svg>
          </div>

          <div className={`md:block  overflow-auto max-h-screen`}>

              <div className={"pb-6 pt-3 sticky top-0 bg-gray-400"}>

                  <div className={"text-center text-xl font-semibold" }>

                      <div className={"text-lg"} >
                          <span className={"font-bold"}>Welcome, </span>

                          <span className={"font-semibold underline italic"} >{auth.userInfo.userName}</span>
                      </div>


                      <div className={"flex flex-row justify-between my-3 px-5"}>

                          <button className=" px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" onClick={()=>{auth.logout()}} >
                              Logout
                          </button>

                          <Link to={"/profile"}>
                              <button className=" px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" onClick={()=>{auth.setNavbarOpen(false)}} >
                                  Profile
                              </button>
                          </Link>

                      </div>

                      <p>
                          \/ People on this group \/
                      </p>
                  </div>

              </div>


              <div className="divide-y divide-gray-500">
                  {users.map((user) => {
                      if(auth.userInfo.userName!==user.name)
                      {
                          if (user.uid===auth.chattingUser)
                          {
                              return <UsersComponent key={user.uid} user={user} selectedUser={"bg-blue-300"} />
                          }
                          return <UsersComponent key={user.uid} user={user} />
                      }
                      return null
                  })}

              </div>

          </div>

      </div>
  );
}