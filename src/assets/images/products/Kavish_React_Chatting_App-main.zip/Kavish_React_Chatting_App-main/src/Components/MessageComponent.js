// noinspection JSIgnoredPromiseFromCall,JSUnresolvedVariable

import {useContext, useEffect, useRef, useState} from "react";
import {query , collection , onSnapshot ,orderBy} from "firebase/firestore"
import authContext from "../Context/Authentication/AuthContext";
import {db} from "../Firebase";
import SingleMessageComponent from "./SingleMessageComponent";
import {Link} from "react-router-dom";
import toast from "react-hot-toast";

export default function MessageComponent()
{
    const auth = useContext(authContext)
    const message = useRef()
    const [recivedMessages,setRecivedMessages] = useState([])

    async function getMessages()
    {
        const ref = collection(db , `messages/singleUserMessage/${auth.userInfo.uid}`)
        const q = query(ref,orderBy("createdAt","asc"))
        await onSnapshot(q , (instance)=>{
            let data = instance.docs.map((doc) => {
                return {...doc.data() , ...{dId : doc.id}}
            });
            data = data.map((msg)=>{
                const date = (new Date(msg.createdAt.seconds * 1000))
                return {...msg ,
                    ...{
                    createdAt:
                        date.toLocaleString("en-GB",{weekday: "short"}) + ", "+
                        date.toLocaleString("en-GB",{ day: "2-digit" }) + "-"+
                        date.toLocaleString("en-GB",{month: "short"}) + "-"+
                        date.toLocaleString("en-GB",{year: "2-digit"}) + ", At "+
                        date.toLocaleString("en-US", {hour: "2-digit"}).substring(0,2) + ":"+
                        date.toLocaleString("en-US",{minute: "2-digit"}) + ":"+
                        date.toLocaleString("en-US",{second: "numeric"}) + " "+
                        date.toLocaleString("en-US", {hour: "numeric"}).substring(2,5)
                }}
            })
            setRecivedMessages(data)
        })
    }

    function formHandler(event)
    {
        event.preventDefault();
        if(auth.chattingUser!=="")
        {
            auth.addMessageToDB(message.current.value , auth.chattingUser )
            message.current.value = "";
        }
        else
        {
            toast.error("Kindly Select a user before sending message")
        }
    }

    const messagesEndRef = useRef(null)

    useEffect(()=>{
        getMessages()
        // eslint-disable-next-line
    }, [])

    useEffect(()=>{
        getMessages()
        // eslint-disable-next-line
    }, [auth.chattingUser])

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
    }, [recivedMessages]);


  return(
      <div className={" w-screen max-h-screen min-h-screen bg-ChatBG bg-cover flex flex-col justify-between "}>

          <div className="overflow-auto ">
              <h2 className=" text-center bg-gray-300 py-5 mb-3 sticky top-0" >

                  <p className={"text-2xl font-bold underline italic lg:pr-32 xl:pr-0"}>
                      Messages
                  </p>

                  <div className={"hidden absolute inset-y-0 lg:flex items-center right-6 top-0"} >

                      <div className={"mr-6 text-xl"} >
                          <span className={"font-bold"}>Welcome, </span>
                          <Link to={"/profile"}>
                              <span className={"font-semibold underline italic"} >{auth.userInfo.userName}</span>
                          </Link>
                      </div>

                      <button className=" px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" onClick={()=>{auth.logout()}} >Logout</button>

                  </div>

              </h2>

              <div>

                  {
                      recivedMessages.map((msg)=>{

                              if( (msg.senderId===auth.userInfo.uid && msg.receiveId===auth.chattingUser ) || (msg.receiveId===auth.userInfo.uid && msg.senderId===auth.chattingUser) )
                              {
                                  if (msg.senderId===auth.userInfo.uid)
                                      return <SingleMessageComponent key={msg.dId} messagesEndRef={messagesEndRef} msg={msg} dynamicHeadingCss={"bg-gray-600"} dynamicBodyCss={"bg-gray-400"} alignMsg={"items-end"} />
                                  return  <SingleMessageComponent key={msg.dId} messagesEndRef={messagesEndRef} msg={msg} dynamicHeadingCss={"bg-green-600"} dynamicBodyCss={"bg-green-400"} alignMsg={"items-start"} />
                              }
                              return null
                      })
                  }

              </div>

          </div>

          <div className={"py-4 bg-gray-300"}>
              <form onSubmit={(event)=>{formHandler(event)}} >
                  <div className={"flex flex-row px-6"}>
                      <textarea rows={1} className=" w-full focus:ring-blue-500 focus:border-blue-500 border border-gray-300 rounded-l-md" placeholder="Add a note" ref={message} required />

                      <button className=" px-4 py-2 border border-transparent text-sm font-medium rounded-r-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" type={"submit"} >
                          Send
                      </button>
                  </div>
              </form>
          </div>

      </div>
  );
}