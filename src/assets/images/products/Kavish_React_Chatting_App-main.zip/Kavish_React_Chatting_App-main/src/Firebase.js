// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {getFirestore} from "firebase/firestore"
import {getAuth} from "firebase/auth"
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBzUjYLiKTITrbRQkdBT9i1NvNLhcd5h9I",
    authDomain: "chatting-app-5254f.firebaseapp.com",
    projectId: "chatting-app-5254f",
    storageBucket: "chatting-app-5254f.appspot.com",
    messagingSenderId: "240484358474",
    appId: "1:240484358474:web:7390fa476c398a7dd149b3"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);



//exporting Firestore Reference
export const db = getFirestore(app)

//exporting Authentication Reference
export const firebaseAuth = getAuth(app)