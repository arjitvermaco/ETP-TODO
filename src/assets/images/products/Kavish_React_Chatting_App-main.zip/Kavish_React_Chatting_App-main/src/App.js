import Login from "./Pages/Login"
import Signup from "./Pages/Signup";
import ForgetPassword from "./Pages/ForgetPassword";
import React, {useContext} from "react";
import {Navigate, Route, Routes} from "react-router-dom";
import Chat from "./Pages/Chat";
import Profile from "./Pages/Profile";
import {Toaster} from "react-hot-toast";
import authContext from "./Context/Authentication/AuthContext";

export default function App()
{
    const auth = useContext(authContext)
  return (
      <div>
          <Toaster/>
          <Routes>
              {
                  /*false condition matched*/
                  !auth.state &&
                  (
                      <>
                          <Route path="/" element={ <Login/> } />
                          <Route path="forgetPassword" element={ <ForgetPassword/> } />
                          <Route path="signup" element={ <Signup/> } />
                      </>
                  )
              }
              {
                  /*false condition matched*/
                  auth.state &&
                  (
                      <>
                          <Route path="/" element={ <Chat/> } />
                          <Route path="profile" element={ <Profile/> } />
                      </>
                  )
              }
              <Route path="*" element={<Navigate to={"/"}/>} />
          </Routes>
      </div>
  )
}