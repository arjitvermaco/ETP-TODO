import AuthContext from "./AuthContext";
import {createUserWithEmailAndPassword , signInWithEmailAndPassword ,sendPasswordResetEmail } from "firebase/auth";
import {db, firebaseAuth} from "../../Firebase";
import {doc, setDoc, getDoc, addDoc, collection, serverTimestamp, getDocs} from "firebase/firestore";
import React, {useEffect, useState} from "react";
import toast from "react-hot-toast";


export default function AuthState(props) 
{

    const [state ,setState] = useState(false)
    const [userInfo , setUserInfo] =useState({})
    const [navbarOpen, setNavbarOpen] = useState(false);
    const [chattingUser , setChattingUser] = useState("")
    let userVerified = false


    useEffect(
        ()=>{
            onReload()
        },
        []
    )


    function resetPasswordFromProfile ()
    {
        sendPasswordResetEmail( firebaseAuth , userInfo.userEmail).then(()=>{
            logout()
            toast("you have been logged out")
            toast.success("An Email has been send to the registered email")
        }).catch(()=>{
            toast.error("There is some problem in sending reset link")
        })
    }

    function resetPasswordFromLogin (email)
    {
        sendPasswordResetEmail( firebaseAuth , email).then(()=>{
            toast.success("An Email has been send to the registered email")
        }).catch(()=>{
            toast.error("There is some problem in sending reset link")
        })
    }


    function onReload()
    {
        setState(JSON.parse(localStorage.getItem("userState")))
        setUserInfo(JSON.parse(localStorage.getItem("userCredential")))
    }

    function logout()
    {
        setChattingUser("")
        localStorage.setItem("userState" , JSON.stringify(false))
        localStorage.setItem("userCredential" , JSON.stringify({}))
        setState(false)
    }

  async function createUser(uEmail , uPass , uName , uPhoneNo)
  {
      uName = (uName.replace(/\s+/g,' ')).trim()
      uEmail = (uEmail.replace(/\s+/g,'')).trim()
      uPhoneNo = (uPhoneNo.replace(/\s+/g,'')).trim()
      await verifyUser(uName.toLowerCase())
      if (userVerified)
      {
          toast.error(`User with '${uName}' Already Exists`)
      }
      else
      {
          createUserWithEmailAndPassword(firebaseAuth , uEmail , uPass).then(
              (userData)=>
              {
                  setDoc(doc(db , "Users" , userData.user.uid),
                      {
                          name : uName,
                          phoneNo : uPhoneNo
                      }).then(()=>{
                      toast.success("Done")
                  })
              }
          ).catch((e)=>{
              toast.error(e.message)
          })
      }
      userVerified = false
  }

  async function userLogin (uEmail , uPass)
  {
      await signInWithEmailAndPassword(firebaseAuth , uEmail , uPass).then( (userCredential)=>
      {
          confirmUser(userCredential)
      }).catch(
          (error)=>{
              toast.error(error.message)
          }
      )
  }

  async function verifyUser(uName)
  {
      const usersSnapshot = await getDocs(collection(db,"Users"));
      const temp = usersSnapshot.docs.map((doc)=>{
          return (doc.data().name.toLowerCase())
      })

      temp.forEach((user)=>{
          if(user===uName)
          {
              userVerified = true
          }
      })


  }

  async function confirmUser(userCredential)
  {
      const userSnapshot = await getDoc( doc(db, "Users", userCredential.user.uid) );
      if (userSnapshot.exists())
      {
          const temp = userSnapshot.data()
          const tempData ={
              ...userInfo ,
              ...{ uid : userCredential.user.uid } ,
              ...{ userName : temp.name } ,
              ...{ userEmail : userCredential.user.email },
              ...{ userPhoneNo : temp.phoneNo }
          }
          setUserInfo(tempData)
          localStorage.setItem("userState" , JSON.stringify(true))
          localStorage.setItem("userCredential" , JSON.stringify(tempData))
          setState(true)
      }
      else
      {
          toast.error("User Doesn't exists")
      }
  }

  function addMessageToDB(message , recID)
  {
      let messageToAdd =
          {
              messageBody: message,
              email: userInfo.userEmail,
              name : userInfo.userName,
              senderId: userInfo.uid,
              receiveId : recID,
              createdAt: serverTimestamp()
          };

      addDoc(collection(db, `messages/singleUserMessage/${recID}`) , messageToAdd).then();
      addDoc(collection(db, `messages/singleUserMessage/${messageToAdd.senderId}`) , messageToAdd).then();
  }

  return(
      <AuthContext.Provider value={
        {
            state : state ,
            createUser : createUser ,
            userLogin : userLogin ,
            userInfo : userInfo ,
            logout : logout ,
            addMessageToDB : addMessageToDB ,
            resetPasswordFromProfile : resetPasswordFromProfile ,
            resetPasswordFromLogin : resetPasswordFromLogin ,
            navbarOpen : navbarOpen ,
            setNavbarOpen : setNavbarOpen ,
            chattingUser : chattingUser ,
            setChattingUser : setChattingUser
        }
      }>
          {props.children}
      </AuthContext.Provider>
  );
}