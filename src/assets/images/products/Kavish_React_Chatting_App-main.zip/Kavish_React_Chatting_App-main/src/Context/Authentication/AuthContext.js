import {createContext} from "react";
const authContext = createContext(null)
export default authContext